

#include<iostream>
using namespace std;

bool positive(int n){
  return n > 0;
}

int main(){
 
  cout << positive(-5) << endl;
}
