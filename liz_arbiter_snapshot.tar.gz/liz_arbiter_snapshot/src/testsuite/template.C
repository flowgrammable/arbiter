template<typename T>
T id(T x) {return x;}

id(3);
