int f(int);                     // OK
double f(double);               // OK

template<typename T>            // OK
   T f(T);
