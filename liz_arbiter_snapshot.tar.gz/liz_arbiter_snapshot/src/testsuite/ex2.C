concept Readable(Regular T) {
    Regular ValueType(Readable);
    ValueType source(T);
}

