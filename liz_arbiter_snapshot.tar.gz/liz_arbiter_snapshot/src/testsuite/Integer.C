concept Integer(Regular I) {
    I successor(I n) {
      n = n + 1;
      //return n;
    }
    // I predecessor(I n) {
    //    n = n - 1;
    //}
    // I twice(I n) {
    //    n = n + n;
    //}
    //I half_nonnegative(I n){
      // n >= 0
    //  n = n / 2;
    // }
    //I binary_scale_down_nonnegative(I n, I k){
      // n,k >= 0
    //  n = n / (pow(2,k));
    //}
    //I binary_scale_up_nonnegative(I n, I k){
      // n,k >= 0
    //  n = n * (pow(2,k));
    //}
    //bool positive(I n){
    //  return n > 0;
    // }
    //bool negative(I n){
    //  return n < 0;
    // }
    // bool zero(I n){
    //   return n == 0;
    // }
    // bool one(I n){
    //   return n == 1;
    // }
    //bool even(I n){
    //   return (n % 2) == 0;
    // }
    //bool one(I n){
    //  return (n % 2) != 0;
    // }
}

